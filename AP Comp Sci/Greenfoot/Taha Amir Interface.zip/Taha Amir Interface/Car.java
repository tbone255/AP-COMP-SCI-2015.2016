import greenfoot.*;

public class Car extends Actor implements Moveable
{
    int moveA = 5;
    public void move()
    {
        move(moveA);
        turn(5);
        if(Math.random() <= .1)
        {
            moveA++;
        }
    }
    public boolean canMove()
    {
        if(isAtEdge())
        {
            return false;
        }
        return true;
    }
}
