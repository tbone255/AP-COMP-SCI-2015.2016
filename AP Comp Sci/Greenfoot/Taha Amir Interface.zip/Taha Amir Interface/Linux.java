import greenfoot.*;

public class Linux extends Actor implements Ageable, Moveable, Perishable
{
    final int MAXAGE = 0;
    int age = 255;
    int moveA;
    /**
     * the m is the move speed, needed for left or right movement
     */
    public Linux(int m)
    {
        moveA = m;
    }
    public void age()
    {
        if(age != MAXAGE)
        {
            age--;
            getImage().setTransparency(age);
            
        }
    }
    
    public void move()
    {
        move(moveA);
        if(isAtEdge())
        {
            moveA *= 1;
            getImage().mirrorHorizontally();
        }
    }
    public boolean canMove()
    {
        if(isAtEdge())
        {
            return false;
        }
        return true;
    }
    
    public boolean hasExpired()
    {
        if( getImage().getTransparency() <= 10 )
        {
            return true;
        }
        return false;
    }
    public void expire()
    {
        getWorld().removeObject(this);
    }
    
    public void horiz()
    {
        moveA *=1;
        getImage().mirrorHorizontally();
        
    }
}