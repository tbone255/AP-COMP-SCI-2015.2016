public interface Moveable
{
    public abstract boolean canMove();
    public abstract void move();
}