public interface Perishable
{   
    boolean hasExpired();
    void expire();
}
