import greenfoot.*;
import java.awt.Color;
public class Banana extends Actor implements Ageable, Perishable
{
    int age = 1;
    final int MAXAGE =20;
    GreenfootImage img = getImage();
    
    public void age()
    {
        img.setColor(new Color(165, 42, 42));
        
        if(age != MAXAGE)
        {
            age++;
            img.scale(img.getWidth() + age/2, img.getHeight() + age);
        }
    }
    
    public boolean hasExpired()
    {
        if(age >= MAXAGE)
        {
            return true;
        }
        return false;
    }
    public void expire()
    {
       img.fill();    
    }
}