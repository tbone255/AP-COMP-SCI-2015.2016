public interface Ageable
{
    public abstract void age();
}