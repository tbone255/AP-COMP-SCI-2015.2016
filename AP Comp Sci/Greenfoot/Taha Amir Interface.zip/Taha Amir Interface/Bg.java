import greenfoot.*;
import java.util.*;
/**
 * Write a description of class Bg here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bg extends World
{

    /**
     * Constructor for objects of class Bg.
     * 
     */
    public Bg()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1024, 768, 1); 

        prepare();
    }

    public void act()
    {
        List moves = getObjects(Moveable.class);
        for(Object o : moves)
        {
            if(((Moveable)o).canMove())
            {
                ((Moveable)o).move();
            }
        }

        List ages = getObjects(Ageable.class);
        for(Object o : ages)
        {
            ((Ageable)o).age();
        }

        List perishes = getObjects(Perishable.class);
        for(Object o : perishes)
        {
            if(((Perishable)o).hasExpired())
            {
                ((Perishable)o).expire();
            }
        }
    }

    /**
     * Prepare the world for the start of the program. That is: create the initial
     * objects and add them to the world.
     */
    private void prepare()
    {
        Linux linux = new Linux(-10);
        addObject(linux, 653, 422);
        linux.horiz();
        Linux linux2 = new Linux(10);
        addObject(linux2, 73, 428);
        Man man = new Man();
        addObject(man, 349, 428);
        Banana banana = new Banana();
        addObject(banana, 942, 701);
        Car car = new Car();
        addObject(car, 442, 486);
    }
}
