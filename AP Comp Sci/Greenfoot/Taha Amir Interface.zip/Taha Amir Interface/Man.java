import greenfoot.*;
import java.awt.Color;
public class Man extends Actor implements Ageable, Moveable, Perishable
{
    int age = 0;
    int MAXAGE = 500;
    int color = 0;
    int moveA = 10;
    public void age()
    {
        age++;
        if(age != MAXAGE)
        {
            GreenfootImage bg = getWorld().getBackground();
        }
    }
    
    public void move()
    {
        move(moveA);
        if(isAtEdge())
        {
            moveA *= -1;
            getImage().mirrorHorizontally();
            
        }
    }
    public boolean canMove()
    {
        if(isTouching(Linux.class))
        {
            return false;
        }
        return true;
    }
    
    public boolean hasExpired()
    {
        if(age == MAXAGE)
        {
            return true;
        }
        return false;
    }
    public void expire()
    {
        getWorld().removeObject(this);
    }
}
